<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="style.css">
  <link rel="shortcut icon" href="https://jesperorb.github.io/cat-deploy/favicon.png" type="image/x-icon">
  <title> Contact </title>
</head>
<body>
  <header>
    <h1> Frontend Blog </h1>
  </header>
  <nav>
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
   <a href="contact.php">Contact</a>
  </nav>
  <main>
    <section style="max-width: 40%">
      <h2 style="text-align:center;"> Contact </h2>
  </main>
  <footer>
  <p>Copyright Datadata</p>
</footer>
</body>
</html>