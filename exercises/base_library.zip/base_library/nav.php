<ul class="tab tab-block">
  <li class="tab-item">
    <a href="?">Home</a>
  </li>
  <li class="tab-item">
    <a href="?page=book">Books</a>
  </li>
</ul>
